INSERT INTO CRD ("Code", "Name", "Level", "TypeId", "ColorId1", "ColorId2", "FormId", "AttributeId", 
	"DigiTypeId1","DigiTypeId2","DigiTypeId3","DigiTypeId4","DigiTypeId5", "BoxId", "DP", 
	"PlayCost", "DigiCost1", "DigiCost2", "DigiLevel1", "DigiLevel2", "EffectId", "DigiEffectId", "SecEffectId")
VALUES
	{0};

