INSERT INTO FRM ("Id", "Name")
VALUES
	{0};

