INSERT INTO EFCT ("Id", "Value", "Type")
VALUES
	({0},'{1}','{2}');

