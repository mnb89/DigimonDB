INSERT INTO CRDBOX ("Id", "Name", "Tag", "TypeId", "ImgUrl")
VALUES
	{0};

