INSERT INTO ATB ("Id", "Name")
VALUES
	{0};

