UPDATE CRDBOX 
SET
	"Name" = '{1}',
	"Tag" = '{2}',
	"TypeId" = {3},
	"ImgUrl" = '{4}'
WHERE
	"Id" = '{0}';

