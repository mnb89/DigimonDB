INSERT INTO CRDIMG ("IsParallel", "Rarity", "BoxId", "CardCode", "ImgUrl")
VALUES
	{0};

