UPDATE CRDBOX 
SET
	"ImgPath" = '{1}'
WHERE
	"Id" = {0};
