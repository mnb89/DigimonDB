INSERT INTO BOXTYPE ("Id", "Name", "Tag")
VALUES
	({0},'{1}',{2});

